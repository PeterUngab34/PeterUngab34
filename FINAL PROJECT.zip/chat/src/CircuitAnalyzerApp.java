import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;
import java.io.*;
import java.util.ArrayList;

public class CircuitAnalyzerApp extends JFrame {

    private JTextField txtVoltage;
    private JTextField txtResistance;
    private JTextField txtCurrent;
    private JTextField txtPower;
    private JComboBox<String> unitVoltage;
    private JComboBox<String> unitResistance;
    private JCheckBox darkModeCheckBox;
    private ArrayList<String> calculationHistory;

    public CircuitAnalyzerApp() {
        setTitle("Enhanced Circuit Analyzer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        calculationHistory = new ArrayList<>();
        initializeUI();
    }

    private void initializeUI() {
        // Set background and layout
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(240, 248, 255)); // Light blue-gray background

        // Header panel with title
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(0, 102, 204)); // Blue header
        JLabel lblTitle = new JLabel("Enhanced Circuit Analyzer", JLabel.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 32));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle);

        // Form panel for input and output
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(245, 245, 245)); // Light gray background
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Create labels and text fields for Voltage, Resistance, and Current
        JLabel lblVoltage = new JLabel("Voltage (V):");
        lblVoltage.setFont(new Font("Arial", Font.PLAIN, 18));
        txtVoltage = new JTextField();

        JLabel lblResistance = new JLabel("Resistance (R):");
        lblResistance.setFont(new Font("Arial", Font.PLAIN, 18));
        txtResistance = new JTextField();

        JLabel lblCurrent = new JLabel("Current (I):");
        lblCurrent.setFont(new Font("Arial", Font.PLAIN, 18));
        txtCurrent = new JTextField();
        txtCurrent.setEditable(false);
        txtCurrent.setBackground(new Color(230, 230, 230)); // Gray background for readonly

        JLabel lblPower = new JLabel("Power (P):");
        lblPower.setFont(new Font("Arial", Font.PLAIN, 18));
        txtPower = new JTextField();
        txtPower.setEditable(false);
        txtPower.setBackground(new Color(230, 230, 230)); // Gray background for readonly

        // Unit selectors for Voltage and Resistance
        String[] voltageUnits = {"V", "mV", "kV"};
        unitVoltage = new JComboBox<>(voltageUnits);
        unitVoltage.setFont(new Font("Arial", Font.PLAIN, 16));

        String[] resistanceUnits = {"Ω", "kΩ", "MΩ"};
        unitResistance = new JComboBox<>(resistanceUnits);
        unitResistance.setFont(new Font("Arial", Font.PLAIN, 16));

        // Dark Mode CheckBox
        darkModeCheckBox = new JCheckBox("Dark Mode");
        darkModeCheckBox.setFont(new Font("Arial", Font.PLAIN, 16));
        darkModeCheckBox.addActionListener(e -> toggleDarkMode());

        // Create buttons
        JButton btnCalculate = new JButton("Calculate");
        btnCalculate.setFont(new Font("Arial", Font.BOLD, 16));
        btnCalculate.setBackground(new Color(0, 204, 102)); // Green button
        btnCalculate.setForeground(Color.WHITE);
        btnCalculate.addActionListener(e -> calculateCircuit());

        JButton btnClear = new JButton("Clear");
        btnClear.setFont(new Font("Arial", Font.BOLD, 16));
        btnClear.setBackground(new Color(255, 51, 51)); // Red button
        btnClear.setForeground(Color.WHITE);
        btnClear.addActionListener(e -> clearFields());

        JButton btnExit = new JButton("Exit");
        btnExit.setFont(new Font("Arial", Font.BOLD, 16));
        btnExit.setBackground(new Color(255, 165, 0)); // Orange button
        btnExit.setForeground(Color.WHITE);
        btnExit.addActionListener(e -> System.exit(0));

        JButton btnSave = new JButton("Save");
        btnSave.setFont(new Font("Arial", Font.BOLD, 16));
        btnSave.setBackground(new Color(102, 204, 255)); // Blue button
        btnSave.setForeground(Color.WHITE);
        btnSave.addActionListener(e -> saveHistory());

        // Add components to form panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(lblVoltage, gbc);
        gbc.gridx = 1;
        formPanel.add(txtVoltage, gbc);
        gbc.gridx = 2;
        formPanel.add(unitVoltage, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(lblResistance, gbc);
        gbc.gridx = 1;
        formPanel.add(txtResistance, gbc);
        gbc.gridx = 2;
        formPanel.add(unitResistance, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(lblCurrent, gbc);
        gbc.gridx = 1;
        formPanel.add(txtCurrent, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(lblPower, gbc);
        gbc.gridx = 1;
        formPanel.add(txtPower, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(darkModeCheckBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(btnCalculate, gbc);
        gbc.gridx = 1;
        formPanel.add(btnClear, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(btnExit, gbc);
        gbc.gridx = 1;
        formPanel.add(btnSave, gbc);

        // Footer panel for credits
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(0, 102, 204));
        JLabel lblFooter = new JLabel("Developed by Peter Paul B. Ungab", JLabel.CENTER);
        lblFooter.setFont(new Font("Arial", Font.ITALIC, 14));
        lblFooter.setForeground(Color.WHITE);
        footerPanel.add(lblFooter);

        // Combine panels
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void calculateCircuit() {
        try {
            double voltage = Double.parseDouble(txtVoltage.getText());
            double resistance = Double.parseDouble(txtResistance.getText());

            if (voltage < 0 || resistance < 0) {
                JOptionPane.showMessageDialog(this, "Voltage and Resistance must be non-negative.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Convert units if necessary
            String voltageUnit = (String) unitVoltage.getSelectedItem();
            if (voltageUnit.equals("mV")) {
                voltage /= 1000; // Convert millivolts to volts
            } else if (voltageUnit.equals("kV")) {
                voltage *= 1000; // Convert kilovolts to volts
            }

            String resistanceUnit = (String) unitResistance.getSelectedItem();
            if (resistanceUnit.equals("kΩ")) {
                resistance *= 1000; // Convert kilohms to ohms
            } else if (resistanceUnit.equals("MΩ")) {
                resistance *= 1000000; // Convert megohms to ohms
            }

            // Calculate current using Ohm's Law: I = V / R
            double current = voltage / resistance;
            double power = voltage * current; // Power: P = V * I

            // Display results
            DecimalFormat df = new DecimalFormat("0.###");
            txtCurrent.setText(df.format(current));
            txtPower.setText(df.format(power));

            // Save calculation to history
            calculationHistory.add("V: " + voltage + " R: " + resistance + " I: " + current + " P: " + power);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for voltage and resistance.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        txtVoltage.setText("");
        txtResistance.setText("");
        txtCurrent.setText("");
        txtPower.setText("");
        unitVoltage.setSelectedIndex(0);
        unitResistance.setSelectedIndex(0);
    }

    private void toggleDarkMode() {
        if (darkModeCheckBox.isSelected()) {
            getContentPane().setBackground(new Color(40, 40, 40));
            darkModeCheckBox.setForeground(Color.WHITE);
        } else {
            getContentPane().setBackground(new Color(240, 248, 255));
            darkModeCheckBox.setForeground(Color.BLACK);
        }
    }

    private void saveHistory() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("calculation_history.txt", true))) {
            for (String entry : calculationHistory) {
                writer.write(entry);
                writer.newLine();
            }
            JOptionPane.showMessageDialog(this, "History saved successfully.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving history.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CircuitAnalyzerApp app = new CircuitAnalyzerApp();
            app.setVisible(true);
        });
    }
}
